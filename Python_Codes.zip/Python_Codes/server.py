import socket

def server():
    host = "127.0.0.1"
    port = 5003  # server port

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((host, port))
    s.listen(1)

    print(f"[SERVER] Listening on {host}:{port}...")

    conn, addr = s.accept()
    print(f"[SERVER] Gateway connected from {addr}")

    while True:
        data = conn.recv(1024).decode()
        if not data:
            break

        print(f"[SERVER] Received from Gateway: {data}")

        # Decide action
        if data == "FIRE ON":
            response = "SPRINKLER ON"
            print("[SERVER] Decision → Sprinkler ON")
        elif data == "FIRE OFF":
            response = "SPRINKLER OFF"
            print("[SERVER] Decision → Sprinkler OFF")
        else:
            response = "UNKNOWN"

        # Send decision back to gateway
        conn.send(response.encode())

    conn.close()

if __name__ == "__main__":
    server()
