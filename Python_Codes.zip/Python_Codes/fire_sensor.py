import socket

def fire_sensor():
    host = "127.0.0.1"
    port = 5001  # gateway port

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    s.send("SENSOR".encode())  # register as sensor
    print("[FIRE SENSOR] Connected to Gateway")

    while True:
        cmd = input("Enter 'on' or 'off': ").strip().lower()
        if cmd == "on":
            s.send("FIRE ON".encode())
        elif cmd == "off":
            s.send("FIRE OFF".encode())
        else:
            print("Invalid input. Use 'on' or 'off'.")

if __name__ == "__main__":
    fire_sensor()
