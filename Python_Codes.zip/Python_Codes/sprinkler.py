import socket

def sprinkler():
    host = "127.0.0.1"
    port = 5001  # gateway port

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    s.send("SPRINKLER".encode())  # register as sprinkler
    print("[SPRINKLER] Connected to Gateway")

    while True:
        data = s.recv(1024).decode()
        if not data:
            break
        if data == "SPRINKLER ON":
            print("[SPRINKLER]  Fire detected → Sprinkler ACTIVATED ")
        elif data == "SPRINKLER OFF":
            print("[SPRINKLER]  Fire cleared → Sprinkler DEACTIVATED")

    s.close()

if __name__ == "__main__":
    sprinkler()
