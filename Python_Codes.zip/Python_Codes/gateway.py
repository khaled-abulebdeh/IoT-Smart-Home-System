import socket
import threading

sprinkler_conn = None
server_socket = None

def handle_sensor(conn):
    global server_socket, sprinkler_conn
    while True:
        data = conn.recv(1024).decode()
        if not data:
            break
        print(f"[GATEWAY] From Sensor: {data}")

        # send to server
        server_socket.send(data.encode())

        # get decision back from server
        response = server_socket.recv(1024).decode()
        print(f"[GATEWAY] From Server: {response}")

        # forward to sprinkler if connected
        if sprinkler_conn:
            sprinkler_conn.send(response.encode())
        else:
            print("[GATEWAY] Warning: No sprinkler connected!")

def gateway():
    global server_socket, sprinkler_conn
    host = "127.0.0.1"
    port = 5001  # gateway port for sensors & sprinkler

    # Listen for sensor & sprinkler
    gw_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    gw_socket.bind((host, port))
    gw_socket.listen(5)
    print(f"[GATEWAY] Listening on {host}:{port}...")

    # Connect to server
    server_host = "127.0.0.1"
    server_port = 5003
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.connect((server_host, server_port))
    print("[GATEWAY] Connected to Server")

    while True:
        conn, addr = gw_socket.accept()
        role = conn.recv(1024).decode().strip()

        if role == "SPRINKLER":
            sprinkler_conn = conn
            print(f"[GATEWAY] Sprinkler connected from {addr}")
        elif role == "SENSOR":
            print(f"[GATEWAY] Sensor connected from {addr}")
            threading.Thread(target=handle_sensor, args=(conn,)).start()
        else:
            print(f"[GATEWAY] Unknown role from {addr}: {role}")

if __name__ == "__main__":
    gateway()
